package com.example.capstone.AadharRestApi.Repository;

import org.springframework.data.repository.CrudRepository;

import com.example.capstone.AadharRestApi.Entity.Admin;

public interface AdminRepo extends CrudRepository<Admin, Integer>{

}
